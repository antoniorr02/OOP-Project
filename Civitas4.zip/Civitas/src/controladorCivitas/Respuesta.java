package src.controladorCivitas;

public enum Respuesta {NO, SI};