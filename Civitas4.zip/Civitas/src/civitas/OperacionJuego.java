
package src.civitas;

public enum OperacionJuego {
  PASAR_TURNO,
  AVANZAR,
  COMPRAR,
  GESTIONAR
}